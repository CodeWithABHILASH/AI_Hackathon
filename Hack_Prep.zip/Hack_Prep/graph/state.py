# graph/state.py
from pydantic import BaseModel
from typing import Optional, Dict, Any

class AgentState(BaseModel):
    file_path: str
    text: Optional[str] = None
    invoice_data: Optional[Dict[str, Any]] = None
    validation: Optional[Dict[str, Any]] = None
    feedback: Optional[str] = None

    # REQUIRED for resume handling
    human_response: Optional[Dict[str, Any]] = None

    # attempt counters (optional but helpful)
    attempts: int = 0
    max_attempts: int = 5
