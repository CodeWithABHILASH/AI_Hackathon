# api_server.py
import json
import os
from typing import Optional
from fastapi import FastAPI, HTTPException, Query, Header
from fastapi.middleware.cors import CORSMiddleware
import requests
from requests.exceptions import RequestException
from pydantic import BaseModel
from dotenv import load_dotenv
from datetime import datetime

load_dotenv()  # load .env if present

app = FastAPI(title="TATA - Drug Interaction API (Open Source)", version="0.2")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load synthetic DB
SYN_DB_PATH = os.getenv("SYN_DB_PATH", "synthetic_drugbank.json")
try:
    with open(SYN_DB_PATH, "r", encoding="utf-8") as f:
        SYN_DATA = json.load(f)
except FileNotFoundError:
    SYN_DATA = {}
    print(f"Warning: synthetic DB not found at {SYN_DB_PATH}.")

# Load DIKG open-source interactions (sample)
DIKG_PATH = os.getenv("DIKG_PATH", "dikg_interactions.json")
try:
    with open(DIKG_PATH, "r", encoding="utf-8") as f:
        DIKG_DATA = json.load(f)
except FileNotFoundError:
    DIKG_DATA = {}
    print("Warning: DIKG dataset not found. Add dikg_interactions.json for open-source interactions.")

RXNORM_BASE = "https://rxnav.nlm.nih.gov/REST"
OPENFDA_BASE = "https://api.fda.gov/drug/event.json"

# Simple in-file audit log
AUDIT_LOG = os.getenv("AUDIT_LOG", "audit.log")
DEMO_API_KEY = os.getenv("DEMO_API_KEY", "demo_key_1234")


class InteractionResponse(BaseModel):
    drug1: str
    drug2: str
    interaction: Optional[dict] = None
    found_in: list = []


class ChatRequest(BaseModel):
    query: str


def audit_write(entry: dict):
    try:
        with open(AUDIT_LOG, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception:
        pass


@app.get("/health")
def health():
    return {"status": "ok"}


from graph.graph import build_graph
from graph.state import AgentState
from llm_client import llm_call

_graph = build_graph()


@app.get("/resolve")
def resolve_drug(name: str = Query(..., description="Drug name to resolve to RxCUI")):
    """
    Resolve a drug NAME to RxNorm RXCUI using public RxNorm API.
    (This is only for normalization — interactions come from DIKG/Synthetic)
    """
    try:
        url = f"{RXNORM_BASE}/rxcui.json?name={requests.utils.quote(name)}"
        r = requests.get(url, timeout=6)
        r.raise_for_status()
        j = r.json()
        rxcui = j.get("idGroup", {}).get("rxnormId", [None])[0]
        return {"name": name, "rxcui": rxcui, "raw": j}
    except RequestException as e:
        raise HTTPException(status_code=502, detail=f"RxNorm lookup failed: {str(e)}")


def _resolve_many(names):
    out = {}
    for n in names:
        try:
            url = f"{RXNORM_BASE}/rxcui.json?name={requests.utils.quote(n)}"
            r = requests.get(url, timeout=6).json()
            out[n] = r.get("idGroup", {}).get("rxnormId", [None])[0]
        except Exception:
            out[n] = None
    return out


@app.get("/interactions")
def interaction_api(drug1: str, drug2: str, x_api_key: str = Header(None)):
    if x_api_key != DEMO_API_KEY:
        raise HTTPException(401, "Unauthorized")

    found_in = []

    d1 = drug1.lower()
    d2 = drug2.lower()

    # -------------------------------------
    # Helper to get RxCUI
    # -------------------------------------
    def get_rxcui(name):
        try:
            url = f"{RXNORM_BASE}/rxcui.json?name={requests.utils.quote(name)}"
            r = requests.get(url, timeout=5).json()
            return r.get("idGroup", {}).get("rxnormId", [None])[0]
        except:
            return None

    rxcui1 = get_rxcui(d1)
    rxcui2 = get_rxcui(d2)

    # -------------------------------------
    # 1️⃣ Try RxNav (official)
    # -------------------------------------
    if rxcui1 and rxcui2:
        try:
            url = f"{RXNORM_BASE}/interaction/list.json?rxcuis={rxcui1}+{rxcui2}"
            r = requests.get(url, timeout=5).json()

            groups = r.get("fullInteractionTypeGroup", [])
            if groups:
                ipair = groups[0]["fullInteractionType"][0]["interactionPair"][0]
                found_in.append("rxnav")

                return {
                    "drug1": drug1,
                    "drug2": drug2,
                    "interaction": {
                        "severity": ipair.get("severity", "unknown"),
                        "description": ipair.get("description", ""),
                        "source": "RxNav"
                    },
                    "found_in": found_in
                }
        except:
            pass

    # -------------------------------------
    # 2️⃣ Try ChemCrow (LangChain chemistry tool)
    # -------------------------------------
    try:
        from langchain_community.tools import chemcrow_tools

        chem = chemcrow_tools.ChemicalAgent()
        response = chem.run(f"Does {drug1} interact with {drug2}? Explain the mechanism.")

        if "no interaction" not in response.lower():
            found_in.append("chemcrow")

            return {
                "drug1": drug1,
                "drug2": drug2,
                "interaction": {
                    "severity": "unknown",
                    "mechanism": response,
                    "source": "chemcrow"
                },
                "found_in": found_in
            }
    except Exception as e:
        print("ChemCrow error:", e)

    # -------------------------------------
    # 3️⃣ Synthetic fallback (guaranteed)
    # -------------------------------------
    syn_d1 = SYN_DATA.get(d1)
    if syn_d1:
        for item in syn_d1.get("interactions", []):
            if item["drug"] == d2:
                found_in.append("synthetic")

                return {
                    "drug1": drug1,
                    "drug2": drug2,
                    "interaction": item,
                    "found_in": found_in
                }

    # -------------------------------------
    # Nothing found
    # -------------------------------------
    return {
        "drug1": drug1,
        "drug2": drug2,
        "interaction": None,
        "found_in": found_in
    }


@app.get("/fda")
def fda_info(drug: str = Query(..., description="Drug name to search in openFDA adverse events"), limit: int = 3, x_api_key: Optional[str] = Header(None)):
    """
    Query openFDA public API for adverse events. Returns raw JSON or error.
    """
    # auth check (same as above)
    if x_api_key and x_api_key != DEMO_API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

    q = f'patient.drug.medicinalproduct:"{drug}"'
    url = f"{OPENFDA_BASE}?search={requests.utils.quote(q)}&limit={int(limit)}"
    try:
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        return {"drug": drug, "raw": r.json()}
    except RequestException as e:
        return {"drug": drug, "error": f"openFDA request failed: {str(e)}"}


@app.get("/synthetic_list")
def synthetic_list(x_api_key: Optional[str] = Header(None)):
    if x_api_key and x_api_key != DEMO_API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")
    return {"count": len(SYN_DATA), "drugs": list(SYN_DATA.keys())}


@app.post("/chat")
def chat_endpoint(payload: ChatRequest, x_api_key: str = Header(None)):
    if x_api_key != DEMO_API_KEY:
        raise HTTPException(status_code=401, detail="Unauthorized")

    query = payload.query.strip()
    if not query:
        raise HTTPException(status_code=400, detail="Query is required")

    # Simple heuristic: split by "and" to infer two drug names, as in main.py
    drugs = []
    if " and " in query.lower():
        parts = query.split("and")
        drugs = [p.strip() for p in parts if p.strip()]

    # If we didn't detect any drug pair, fall back to a simple conversational reply
    if not drugs:
        prompt = f"""
You are a friendly clinical assistant chatting with a clinician.

The user said:
{query}

Respond briefly and conversationally. If they haven't asked about a drug interaction yet,
you can greet them, invite them to describe the drugs and patient context, or answer any
general clinical question they asked. Avoid using markdown bullets or asterisks.
"""

        summary = llm_call(prompt)
        audit_write(
            {
                "ts": datetime.utcnow().isoformat(),
                "type": "chat_smalltalk",
                "query": query,
                "drugs": [],
                "summary_present": bool(summary),
            }
        )
        return {"summary": summary, "raw": {"mode": "smalltalk"}}

    # Otherwise, run full interaction graph workflow
    state = AgentState(query=query, drugs=drugs or None)
    result = _graph.invoke(state.model_dump())

    summary = result.get("summary")
    if not summary:
        summary = "No summary generated. Please check the query format or backend configuration."

    # Optional: write to audit log
    audit_write(
        {
            "ts": datetime.utcnow().isoformat(),
            "type": "chat",
            "query": query,
            "drugs": drugs,
            "summary_present": bool(result.get("summary")),
        }
    )

    return {"summary": summary, "raw": result}
