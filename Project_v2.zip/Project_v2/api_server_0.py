# api_server.py
import json
import os
from typing import Optional
from fastapi import FastAPI, HTTPException, Query
import requests
from requests.exceptions import RequestException
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()  # load .env if present

app = FastAPI(title="TATA - Drug Interaction API (Open Source)", version="0.1")

# Load synthetic DB
SYN_DB_PATH = os.getenv("SYN_DB_PATH", "synthetic_drugbank.json")
try:
    with open(SYN_DB_PATH, "r", encoding="utf-8") as f:
        SYN_DATA = json.load(f)
except FileNotFoundError:
    SYN_DATA = {}
    print(f"Warning: synthetic DB not found at {SYN_DB_PATH}. Create one for offline demo.")

RXNORM_BASE = "https://rxnav.nlm.nih.gov/REST"
OPENFDA_BASE = "https://api.fda.gov/drug/event.json"


class InteractionResponse(BaseModel):
    drug1: str
    drug2: str
    interaction: Optional[dict] = None
    found_in: list = []


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/resolve")
def resolve_drug(name: str = Query(..., description="Drug name to resolve to RxCUI")):
    """
    Resolve a drug NAME to RxNorm RXCUI using public RxNorm API.
    """
    try:
        url = f"{RXNORM_BASE}/rxcui.json?name={requests.utils.quote(name)}"
        r = requests.get(url, timeout=6)
        r.raise_for_status()
        j = r.json()
        rxcui = j.get("idGroup", {}).get("rxnormId", [None])[0]
        return {"name": name, "rxcui": rxcui, "raw": j}
    except RequestException as e:
        raise HTTPException(status_code=502, detail=f"RxNorm lookup failed: {str(e)}")


@app.get("/interactions", response_model=InteractionResponse)
def interaction_api(drug1: str = Query(...), drug2: str = Query(...)):
    """
    1. Resolve RxNorm IDs
    2. Try RxNorm Interaction API (REAL data)
    3. Fallback to synthetic data if needed
    """

    # Step 1 — Resolve drug names to RxCUI
    def get_rxcui(name):
        url = f"{RXNORM_BASE}/rxcui.json?name={requests.utils.quote(name)}"
        try:
            r = requests.get(url, timeout=6).json()
            return r.get("idGroup", {}).get("rxnormId", [None])[0]
        except:
            return None

    rxcui1 = get_rxcui(drug1)
    rxcui2 = get_rxcui(drug2)

    found_in = []

    # Step 2 — Try REAL RxNorm Interaction API
    if rxcui1 and rxcui2:
        try:
            url = f"{RXNORM_BASE}/interaction/list.json?rxcuis={rxcui1}+{rxcui2}"
            r = requests.get(url, timeout=8)
            r.raise_for_status()
            data = r.json()

            groups = data.get("fullInteractionTypeGroup", [])
            if groups:
                # Extract first interaction (simple)
                interaction = groups[0]["fullInteractionType"][0]["interactionPair"][0]

                found_in.append("rxnorm_api")

                return InteractionResponse(
                    drug1=drug1,
                    drug2=drug2,
                    interaction={
                        "severity": interaction.get("severity", "unknown"),
                        "description": interaction.get("description", ""),
                        "rxcui1": rxcui1,
                        "rxcui2": rxcui2
                    },
                    found_in=found_in
                )
        except:
            pass  # if API fails → fallback

    # Step 3 — Synthetic fallback
    d1 = SYN_DATA.get(drug1.lower())
    d2 = SYN_DATA.get(drug2.lower())

    if d1:
        found_in.append("synthetic")

    if d1:
        for item in d1.get("interactions", []):
            if item["drug"].lower() == drug2.lower():
                return InteractionResponse(
                    drug1=drug1,
                    drug2=drug2,
                    interaction=item,
                    found_in=found_in
                )

    return InteractionResponse(drug1=drug1, drug2=drug2, interaction=None, found_in=found_in)



@app.get("/fda")
def fda_info(drug: str = Query(..., description="Drug name to search in openFDA adverse events"), limit: int = 3):
    """
    Query openFDA public API for adverse events. Returns raw JSON or error.
    """
    q = f'patient.drug.medicinalproduct:"{drug}"'
    url = f"{OPENFDA_BASE}?search={requests.utils.quote(q)}&limit={int(limit)}"
    try:
        r = requests.get(url, timeout=8)
        r.raise_for_status()
        return {"drug": drug, "raw": r.json()}
    except RequestException as e:
        # return a helpful message for demo, but don't crash
        return {"drug": drug, "error": f"openFDA request failed: {str(e)}"}


# small utility endpoint to return synthetic DB keys
@app.get("/synthetic_list")
def synthetic_list():
    return {"count": len(SYN_DATA), "drugs": list(SYN_DATA.keys())}
