# graph/state.py
from typing import Optional, List, Dict
from pydantic import BaseModel

class AgentState(BaseModel):
    query: Optional[str] = None
    drugs: Optional[List[str]] = None

    # data we collect
    resolved: Optional[Dict] = None       # RxNav IDs
    interaction: Optional[Dict] = None    # synthetic / DIKG
    fda: Optional[Dict] = None            # openFDA
    summary: Optional[str] = None         # final LLM output
