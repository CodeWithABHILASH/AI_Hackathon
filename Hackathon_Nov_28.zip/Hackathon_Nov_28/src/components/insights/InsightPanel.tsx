export function InsightPanel() {
  // This panel intentionally renders nothing by default.
  // It is reserved for future use with real agent-driven props.
  return null;
}
