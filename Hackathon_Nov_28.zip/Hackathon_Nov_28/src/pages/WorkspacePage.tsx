import { ChatPanel } from '../components/chat/ChatPanel';

export function WorkspacePage() {
  return (
    <div className="flex h-full flex-col">
      <ChatPanel />
    </div>
  );
}
