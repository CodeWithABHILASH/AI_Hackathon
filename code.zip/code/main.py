from graph.builder import build_workflow
from graph.state import GraphState
from IPython.display import Image, display

# --- Mock Documents for the Hackathon Demo ---
# (Using strings ensures no PDF loading errors during presentation)
DOCUMENT_1 = """
CONTRACT AGREEMENT A
Payment Terms: The Client shall pay the Provider $5,000 USD.
Timeline: Payment is due within 30 days of invoice.
Penalties: Late payments incur a 5% fee.
"""

DOCUMENT_2 = """
CONTRACT AGREEMENT B
Payment Terms: The Client shall pay the Provider $6,500 USD.
Timeline: Payment is due within 45 days of invoice.
Penalties: Late payments incur a 2% fee.
"""

def main():
    print("🚀 Initializing Hackathon AI Agent...")
    workflow = build_workflow()

    # Optional: Print the graph structure
    try:
        # If you have graphviz installed, this saves a PNG
        print("Generating Graph Image...")
        with open("workflow_diagram.png", "wb") as f:
            f.write(workflow.get_graph().draw_mermaid_png())
        print("Saved 'workflow_diagram.png'")
    except Exception:
        print("Skipping image generation (Graphviz not found).")

    # Initialize State
    initial_state = GraphState(document_texts=[DOCUMENT_1, DOCUMENT_2])
    
    print("\n--- System Ready. Type 'quit' to exit. ---")
    
    # Interactive Loop
    while True:
        try:
            user_input = input("\nUSER: ")
            if user_input.lower() in ["quit", "exit"]:
                break
            
            # Update state with new query
            initial_state.query = user_input
            
            # Stream events from the graph
            # recursion_limit=50 allows for long conversations
            config = {"recursion_limit": 50}
            
            for event in workflow.stream(initial_state, config=config):
                for node_name, values in event.items():
                    if node_name == "qa_node":
                        print(f"\n🤖 AI ANSWER: {values['rag_answer']}")
                    elif node_name == "comparison_node":
                        print(f"\n📊 COMPARISON RESULT: {values['comparison_results']}")
                    elif node_name == "end_node":
                        print("\nSystem: Exiting workflow loop.")
                        return

        except KeyboardInterrupt:
            break
        except Exception as e:
            print(f"Error: {e}")

if __name__ == "__main__":
    main()