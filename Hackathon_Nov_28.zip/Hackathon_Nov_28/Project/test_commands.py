http://localhost:8000/docs → interactive OpenAPI docs (auto-generated)

http://localhost:8000/health → should return {"status":"ok"}

Example resolve: http://localhost:8000/resolve?name=aspirin

Example interaction: http://localhost:8000/interactions?drug1=aspirin&drug2=warfarin

Example openFDA: http://localhost:8000/fda?drug=aspirin&limit=2

uvicorn api_server:app --reload --host 0.0.0.0 --port 8000