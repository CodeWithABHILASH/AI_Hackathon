# graph/tools.py
import json
from pathlib import Path
import PyPDF2
import shutil
from typing import Dict, Any

from .client import get_azure_client

VERIFIED_FOLDER = "verified_invoices"
PENDING_FOLDER = "pending_invoices"

Path(VERIFIED_FOLDER).mkdir(exist_ok=True)
Path(PENDING_FOLDER).mkdir(exist_ok=True)

def tool(fn):
    fn._is_tool = True
    return fn

# ---------------------------
# Extract text from PDF ONLY
# ---------------------------
@tool
def extract_text_from_pdf(file_path: str) -> str:
    text = ""
    try:
        with open(file_path, "rb") as f:
            reader = PyPDF2.PdfReader(f)
            for page in reader.pages:
                txt = page.extract_text() or ""
                text += txt + "\n"
    except Exception as e:
        print(f"PDF extraction error: {e}")
    return text.strip()

# ---------------------------
# Extract Invoice JSON using Azure LLM
# ---------------------------

@tool
def extract_invoice_json(text: str, feedback: str = None) -> Dict[str, Any]:
    client = get_azure_client()

    print(text)

    prompt = """
        Extract ALL primary invoice fields from this invoice text and return valid JSON only.

        Required fields:
        - invoice_number
        - invoice_date
        - due_date
        - vendor_name
        - vendor_address
        - customer_name
        - customer_address
        - line_items (description, quantity, unit_price, total)
        - subtotal
        - tax_amount
        - total_amount
        - currency

        If a field is not present, return "N/A" or empty array.

        Return ONLY JSON.
        """

    if feedback:
        prompt += f"\n\nIMPORTANT FEEDBACK FROM HUMAN REVIEW:\n{feedback}\nFix the extraction accordingly."

    messages = [
        {"role": "user", "content": f"{prompt}\n\nInvoice Text:\n{text}"}
    ]

    try:
        response = client.invoke(messages)
        result_text = response.content.strip()

        import re
        # Remove all backtick fences regardless of formatting
        cleaned = re.sub(r"```json|```", "", result_text).strip()

        return json.loads(cleaned)
    except Exception as e:
        print("LLM Extraction Error:", e)
        print("RAW returned:", result_text)
        return {}

# ---------------------------
# Validator
# ---------------------------
@tool
def validate_invoice_json(invoice: Dict[str, Any]) -> Dict[str, Any]:
    issues = []

    required = ["invoice_number", "invoice_date", "vendor_name", "total_amount"]

    for f in required:
        if not invoice.get(f) or invoice.get(f) == "N/A":
            issues.append(f"Missing required field: {f}")

    if invoice.get("line_items") in [None, [], "N/A"]:
        issues.append("line_items missing or empty")

    status = "valid" if not issues else "invalid"
    return {"status": status, "issues": issues}

# ---------------------------
# Save Invoice JSON
# ---------------------------
@tool
def save_invoice(invoice: Dict[str, Any], original_file: str) -> Dict[str, Any]:
    file_name = Path(original_file).stem
    json_path = Path(VERIFIED_FOLDER) / f"{file_name}.json"

    with open(json_path, "w") as f:
        json.dump(invoice, f, indent=2)

    shutil.copy2(original_file, VERIFIED_FOLDER)

    return {"status": "saved", "json_path": str(json_path)}
