import os
import httpx
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI, OpenAIEmbeddings

client = httpx.Client(verify=False)
load_dotenv()

def get_llm(temperature=0.2):
    """Returns an authenticated Azure Chat Client"""
    return  ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-g0RigALF05KUmlonLK3JHg",
    http_client=client,
    )


def get_embeddings():
    """Returns an authenticated Azure Embeddings Client"""
    return OpenAIEmbeddings(
        base_url="https://genailab.tcs.in",
        model="azure/genailab-maas-text-embedding-3-large",
        api_key="sk-g0RigALF05KUmlonLK3JHg",
        http_client=client,
    )