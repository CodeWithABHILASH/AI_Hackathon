import os
import httpx
from langchain_openai import ChatOpenAI

client = httpx.Client(verify=False)

def call_llm(query: str) -> str:
    base_url = os.environ.get("GENAI_BASE_URL", "https://genailab.tcs.in")
    model = os.environ.get("GENAI_MODEL", "azure/genailab-maas-gpt-4o")
    api_key = os.environ.get("GENAI_API_KEY")

    if not api_key:
        raise RuntimeError("GENAI_API_KEY environment variable is not set")

    llm = ChatOpenAI(
        base_url=base_url,
        model=model,
        api_key=api_key,
        http_client=client,
    )

    prompt = (
        "You are a helpful assistant. "
        "Always answer in clear, simple language and structure your reply as:\n"
        "1. Summary (2-3 short sentences)\n"
        "2. Detailed Explanation (bullet points, if useful)\n"
        "3. Next Steps or Recommendations.\n\n"
        "If you include any code:\n"
        "- Use correct indentation.\n"
        "- Wrap the code in Markdown fenced blocks like ```python or ```javascript.\n"
        "- Do not mix multiple languages in one code block.\n\n"
        "User question or request:\n"
        f"{query}"
    )

    result = llm.invoke(prompt)
    content = getattr(result, "content", None)
    return content if content is not None else str(result)