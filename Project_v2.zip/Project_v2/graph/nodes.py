# graph/nodes.py
from llm_client import llm_call
from utils.logger import log
import re, json

def router_node(state):
    log("router_node (LLM-based) triggered")

    prompt = f"""
Classify the user message into EXACTLY one of:
GREETING, DEMOGRAPHY, INTERACTION, SINGLE_DRUG, GENERAL

Definitions:
- INTERACTION: User asks about the interaction between two or more drugs (e.g. "Can I take aspirin and warfarin together?").
- SINGLE_DRUG: User asks about a single drug only (e.g. "What are the side effects of aspirin?").

Examples:
User message: "Can I take aspirin and warfarin together?"
Output:
{{
  "action": "INTERACTION",
  "items": ["aspirin", "warfarin"],
  "demographics": {{}}
}}

User message: "What are the side effects of aspirin?"
Output:
{{
  "action": "SINGLE_DRUG",
  "items": ["aspirin"],
  "demographics": {{}}
}}

User message: "I am a 65 year old male."
Output:
{{
  "action": "DEMOGRAPHY",
  "items": [],
  "demographics": {{"age": 65, "gender": "male"}}
}}

User message: "Hi"
Output:
{{
  "action": "GREETING",
  "items": [],
  "demographics": {{}}
}}

User message: "Tell me about painkillers."
Output:
{{
  "action": "GENERAL",
  "items": [],
  "demographics": {{}}
}}

Now classify:
User message: "{state.query}"

Return ONLY JSON:
{{
  "action": "",
  "items": [],
  "demographics": {{}}
}}
"""

    raw = llm_call(prompt) or ""
    print("\n🔴 RAW LLM ROUTER OUTPUT:\n", raw, "\n")

    cleaned = raw.replace("```json", "").replace("```", "").strip()
    print("\n🟢 CLEANED ROUTER OUTPUT:\n", cleaned, "\n")

    match = re.search(r"\{.*\}", cleaned, re.DOTALL)
    if not match:
        return {"run_list": ["tavily"]}

    try:
        data = json.loads(match.group(0))
    except:
        return {"run_list": ["tavily"]}

    action = data.get("action", "GENERAL")
    items = data.get("items", [])
    demo = data.get("demographics", {})

    # Correction: If LLM says SINGLE_DRUG but items > 1, treat as INTERACTION
    if action == "SINGLE_DRUG" and len(items) > 1:
        action = "INTERACTION"

    if action == "GREETING":
        return {"run_list": ["tavily"]}

    if action == "DEMOGRAPHY":
        return {"run_list": ["demography"], "demographics": demo}

    if action == "INTERACTION":
        return {"run_list": ["resolve", "interaction", "fda"], "drugs": items}

    if action == "SINGLE_DRUG":
        return {"run_list": ["single_drug_info", "fda"], "drugs": items}

    return {"run_list": ["tavily"]}
    

def safe(x):
    return "N/A" if x in (None, [], {}, "") else x

def llm_node(state):
    log("llm_node triggered")

    prompt = f"""
You are an assistant that provides simple, neutral, educational summaries.

User message: {state.query}

Mentioned items: {safe(state.drugs)}
Lookup info: {safe(state.resolved)}, {safe(state.interaction)}, {safe(state.fda)}, {safe(state.single_info)}
Web info: {safe(state.tavily)}

Return normal text only.
"""
    response = llm_call(prompt)
    return {"summary": response}
