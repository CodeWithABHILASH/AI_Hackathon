# graph/workflow.py
from langgraph.graph import StateGraph, END
from langgraph.types import Interrupt
from .state import AgentState
from . import nodes

def create_workflow():
    graph = StateGraph(AgentState)

    # ---- Nodes ----
    graph.add_node("extract_text", nodes.extract_text_agent)
    graph.add_node("extract_invoice", nodes.invoice_extractor_agent)
    graph.add_node("validate", nodes.validator_agent)

    # This node ALWAYS triggers interrupt
    graph.add_node("human_review", nodes.human_review_interrupt)

    graph.add_node("save", nodes.save_agent)
    graph.add_node("manual_edit", nodes.manual_edit_agent)  # If you want manual edit as a separate path

    graph.set_entry_point("extract_text")

    # ---- Linear sequence ----
    graph.add_edge("extract_text", "extract_invoice")
    graph.add_edge("extract_invoice", "validate")
    graph.add_edge("validate", "human_review")

    # IMPORTANT: No outgoing edge from human_review
    # graph.add_edge("human_review", ...)  <-- DO NOT ADD THIS

    graph.add_edge("save", END)

    return graph.compile()
