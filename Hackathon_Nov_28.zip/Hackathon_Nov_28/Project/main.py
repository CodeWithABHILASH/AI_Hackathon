# main.py
from graph.graph import build_graph
from graph.state import AgentState

graph = build_graph()

def run_agent_turn(query):
    initial = AgentState(query=query, drugs=[])
    result = graph.invoke(initial.model_dump())
    return result["summary"]

if __name__ == "__main__":
    print("💊 Drug Interaction Chatbot — Type 'quit' to exit\n")

    while True:
        user_input = input("You: ")

        if user_input.lower() in ["quit", "exit", "bye"]:
            print("Bot: Take care! Goodbye 👋")
            break

        # Extract drug names from user input:
        # Simple hack: split by 'and'
        if "and" in user_input:
            parts = user_input.split("and")
            drugs = [p.strip() for p in parts]
        else:
            print("Bot: Please ask using format: 'aspirin and warfarin'")
            continue

        state = AgentState(query=user_input, drugs=drugs)
        result = graph.invoke(state.model_dump())

        print("\nBot:", result["summary"])
        print()
