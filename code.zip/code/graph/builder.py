from langgraph.graph import StateGraph
from graph.state import GraphState
from graph.nodes import decision_node, comparison_node, qa_node, end_node

def build_workflow():
    # 1. Initialize Graph
    graph = StateGraph(GraphState)

    # 2. Add Nodes
    graph.add_node("decision_node", decision_node)
    graph.add_node("comparison_node", comparison_node)
    graph.add_node("qa_node", qa_node)
    graph.add_node("end_node", end_node)

    # 3. Define Conditional Logic
    def route_fn(state: GraphState) -> str:
        return state.flow_type

    graph.add_conditional_edges(
        "decision_node",
        route_fn,
        {
            "comparison": "comparison_node",
            "rag": "qa_node",
            "end": "end_node"
        }
    )

    # 4. Define Loops (Return to decision after work is done)
    graph.add_edge("comparison_node", "decision_node")
    graph.add_edge("qa_node", "decision_node")

    # 5. Set Entry Point
    graph.set_entry_point("decision_node")
    
    return graph.compile()