# graph/state.py
from pydantic import BaseModel, Field
from typing import List, Any, Dict, Optional

class AgentState(BaseModel):
    query: str
    run_list: List[str] = Field(default_factory=list)     # <-- router writes here

    # Data from tools
    drugs: List[str] = Field(default_factory=list)
    demographics: Dict[str, Any] = Field(default_factory=dict)

    resolved: Any = None
    interaction: Any = None
    fda: Any = None
    single_info: Any = None
    tavily: Any = None

    summary: Optional[str] = None
