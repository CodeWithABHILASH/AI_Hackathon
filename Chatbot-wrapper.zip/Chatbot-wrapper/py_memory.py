from typing import List, Dict


_conversations: Dict[str, List[dict]] = {}


def get_memory(user_id: str) -> List[dict]:
    if user_id not in _conversations:
        _conversations[user_id] = []
    return _conversations[user_id]


def add_message(user_id: str, role: str, content: str) -> None:
    chat = get_memory(user_id)
    chat.append({"role": role, "content": content})


def clear_memory(user_id: str) -> None:
    _conversations[user_id] = []
