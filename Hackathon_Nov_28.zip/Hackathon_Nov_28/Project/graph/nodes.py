# graph/nodes.py
from llm_client import llm_call

def router_node(state):
    return {
        "__run__": ["resolve", "interaction", "fda"]
    }

def llm_node(state):
    prompt = f"""
You are a clinical drug–interaction assistant in a chat with a clinician.

User query:
{state.query}

Drugs mentioned:
{state.drugs}

Structured data you have access to:
- RxNorm resolution: {state.resolved}
- Interaction data (DIKG / RxNav / synthetic): {state.interaction}
- FDA adverse event evidence: {state.fda}

Respond in a concise, conversational way (as if in a chat), but still clinically precise.

In your answer, cover:
- Interaction risk
- Severity
- Mechanism (brief, in plain language where possible)
- Recommended clinical actions / monitoring
- Your confidence and what data it is based on

Use short paragraphs and clear headings or line breaks, but do NOT use markdown bullets or asterisks.
Write directly to the clinician ("You may want to…").
If information is limited or uncertain, say so explicitly.
"""

    summary = llm_call(prompt)
    return {"summary": summary}
