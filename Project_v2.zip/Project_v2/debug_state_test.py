from graph.state import AgentState

print("Creating s1")
s1 = AgentState(query="q1")
s1.run_list.append("resolve")
print("s1.run_list:", s1.run_list)

print("Creating s2")
s2 = AgentState(query="q2")
print("s2.run_list:", s2.run_list)

print("Creating s3")
s3 = AgentState(query="q3")
print("s3.run_list:", s3.run_list)

# Also show identities to prove whether the lists are the same object
print("s1.run_list id:", id(s1.run_list))
print("s2.run_list id:", id(s2.run_list))
print("s3.run_list id:", id(s3.run_list))
