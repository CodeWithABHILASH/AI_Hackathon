from llm_client import get_llm  
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser

def route_query(query: str):
    llm = get_llm(temperature=0.0)
    system_prompt = """
            You are an AI assistant that classifies user queries into three categories:
            - "compare" if the query involves comparing two documents.
            - "rag" if the query requires question-answering with a retrieval-based solution.
            - "end" if the user wants to quit/exit.

            Return the response in **strict JSON format**, with **only one key**: classifier.
            Do not include any explanations or extra text.
            """
    router_prompt = ChatPromptTemplate([
    ("system",system_prompt),
    ("user", "{query}")
    ])

    # structured_llm= llm.with_structured_output(router_class)
    parser = JsonOutputParser()
    chain=router_prompt | llm |parser
    response=chain.invoke({"query":query})
    return response
