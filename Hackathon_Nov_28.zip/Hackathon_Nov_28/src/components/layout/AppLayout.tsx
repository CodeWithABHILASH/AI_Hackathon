import { ReactNode } from 'react';
import { useTheme } from '../../context/ThemeContext';
import { useAuth } from '../../context/AuthContext';
import { Sidebar } from './Sidebar';
import { useNavigate } from 'react-router-dom';

interface AppLayoutProps {
  children: ReactNode;
}

export function AppLayout({ children }: AppLayoutProps) {
  const { theme, toggleTheme } = useTheme();
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-slate-100 text-slate-900 dark:bg-slate-950 dark:text-slate-50">
      <Sidebar />
      <div className="flex flex-1 flex-col border-l border-slate-200/10">
        <header className="flex items-center justify-between px-4 py-3 border-b border-slate-200/10 bg-white/70 dark:bg-slate-900/70 backdrop-blur">
          <div className="flex flex-col">
            <span className="text-sm font-semibold tracking-tight">Drug Interaction Assistant</span>
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={toggleTheme}
              className="inline-flex items-center gap-1 rounded-full border border-slate-200/40 bg-slate-50 px-3 py-1 text-xs font-medium text-slate-700 shadow-sm hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              <span className="h-4 w-4 rounded-full bg-yellow-400 dark:hidden" />
              <span className="hidden h-4 w-4 rounded-full bg-slate-900 dark:inline-block" />
              <span>{theme === 'dark' ? 'Dark' : 'Light'} mode</span>
            </button>
            {user && (
              <div className="flex items-center gap-2 text-xs">
                <div className="flex flex-col text-right">
                  <span className="font-medium">{user.email}</span>
                  <span className="text-[11px] text-emerald-500">Authenticated</span>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="rounded-full border border-slate-200/40 px-3 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-100 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
                >
                  Logout
                </button>
              </div>
            )}
          </div>
        </header>
        <main className="flex-1 overflow-hidden bg-slate-50/60 p-4 dark:bg-slate-950">
          <div className="h-full rounded-xl border border-slate-200/60 bg-white/80 p-3 shadow-sm backdrop-blur dark:border-slate-800 dark:bg-slate-900/80">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
}
