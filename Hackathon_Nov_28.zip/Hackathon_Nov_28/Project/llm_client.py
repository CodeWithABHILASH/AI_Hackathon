# llm_client.py
import os
import httpx
client = httpx.Client(verify=False)
from langchain_openai import ChatOpenAI

def llm_call(prompt: str):
    llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key="sk-8Ap3UJ4YXBMf0_cWosJbmg",
    http_client=client,
    )

    return llm.invoke(f"{prompt}").content


