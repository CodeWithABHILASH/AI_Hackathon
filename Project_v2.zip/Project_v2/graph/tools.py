import requests
import json
import os
from dotenv import load_dotenv
from utils.logger import log

load_dotenv()
API_BASE = "http://localhost:8000"

# Synthetic DB
with open("synthetic_drugbank.json", "r") as f:
    SYN_DATA = json.load(f)


def demography_tool(state):
    log("demography_tool triggered")
    return {"demographics": state.demographics}


def resolve_tool(state):
    log("resolve_tool triggered")
    if not state.drugs:
        return {"resolved": None}
    drug = state.drugs[0]
    r = requests.get(f"{API_BASE}/resolve", params={"name": drug})
    return {"resolved": r.json()}


def interaction_tool(state):
    log("interaction_tool triggered")
    if len(state.drugs) < 2:
        return {"interaction": None}
    d1, d2 = state.drugs[0].lower(), state.drugs[1].lower()  # <-- force lowercase
    headers = {"x-api-key": "demo_key_1234"}
    r = requests.get(f"{API_BASE}/interactions", params={"drug1": d1, "drug2": d2}, headers=headers)
    return {"interaction": r.json()}


def fda_tool(state):
    log("fda_tool triggered")
    if not state.drugs:
        return {"fda": None}
    drug = state.drugs[0]
    r = requests.get(f"{API_BASE}/fda", params={"drug": drug})
    return {"fda": r.json()}


def single_drug_tool(state):
    log("single_drug_tool triggered")
    drug = state.drugs[0].lower()
    return {"single_info": SYN_DATA.get(drug, None)}


def tavily_tool(state):
    log("tavily_tool triggered")
    return {"tavily": f"General answer for: {state.query}"}
