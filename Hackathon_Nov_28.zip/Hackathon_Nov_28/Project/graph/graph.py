# graph/graph.py
from langgraph.graph import StateGraph, END
from graph.state import AgentState
from graph.nodes import router_node, llm_node
from graph.tools import resolve_tool, interaction_tool, fda_tool

def build_graph():
    workflow = StateGraph(AgentState)

    # NODES
    workflow.add_node("router", router_node)
    workflow.add_node("resolve", resolve_tool)
    workflow.add_node("interaction", interaction_tool)
    workflow.add_node("fda", fda_tool)
    workflow.add_node("llm", llm_node)

    # ENTRY
    workflow.set_entry_point("router")

    # EDGES FOR LANGGRAPH V1
    workflow.add_edge("router", "resolve")
    workflow.add_edge("router", "interaction")
    workflow.add_edge("router", "fda")

    workflow.add_edge("resolve", "llm")
    workflow.add_edge("interaction", "llm")
    workflow.add_edge("fda", "llm")

    workflow.add_edge("llm", END)

    return workflow.compile()
