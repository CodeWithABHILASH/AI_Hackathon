# graph/nodes.py
from .state import AgentState
from .tools import extract_text_from_pdf, extract_invoice_json, validate_invoice_json, save_invoice
from langgraph.types import Interrupt
import json

def extract_text_agent(state: AgentState) -> AgentState:
    txt = extract_text_from_pdf(state.file_path)
    state.text = txt
    return state

def invoice_extractor_agent(state: AgentState) -> AgentState:
    # uses state.feedback if provided
    state.invoice_data = extract_invoice_json(state.text or "", feedback=state.feedback)
    return state

def validator_agent(state: AgentState) -> AgentState:
    state.validation = validate_invoice_json(state.invoice_data or {})
    return state

def human_review_interrupt(state: AgentState):
    print("🔥 human_review_interrupt EXECUTED")  # debug
    # Use Interrupt to expose details for UI/main.py
    return Interrupt(value={
        "question": "Approve this invoice?",
        "invoice_data": state.invoice_data,
        "validation": state.validation
    })

def human_review_router(state: AgentState) -> AgentState:
    choice = input("Approve (a) | Reject (r) | Manual Edit (e): ").strip().lower()
    if choice == "a":
        state.human_response = "approve"
    elif choice == "r":
        state.human_response = "reject"
    elif choice == "e":
        state.human_response = "edit"
    else:
        state.human_response = "invalid"
    return state

def manual_edit_agent(state: AgentState) -> AgentState:
    while True:
        corrected_str = input("Paste corrected JSON for manual edit:\n").strip()
        try:
            corrected_json = json.loads(corrected_str)
            state.invoice_data = corrected_json
            break
        except Exception as e:
            print("❌ Invalid JSON. Please paste only the corrected invoice JSON object. Error:", e)
    return state

def save_agent(state: AgentState) -> AgentState:
    res = save_invoice(state.invoice_data or {}, state.file_path)
    # Optionally attach save result
    state.validation = state.validation or {}
    state.validation["save_result"] = res
    return state
