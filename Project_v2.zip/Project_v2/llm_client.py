# llm_client.py
import os
import httpx
client = httpx.Client(verify=False)
from langchain_openai import ChatOpenAI

def llm_call(prompt: str):
    llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4o",
    api_key="sk-8Ap3UJ4YXBMf0_cWosJbmg",
    http_client=client,
    )
    result = llm.invoke(prompt).content
    return result
 


  


