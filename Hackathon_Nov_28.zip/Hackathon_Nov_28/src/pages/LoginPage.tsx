import { FormEvent, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';

export function LoginPage() {
  const { login } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const navigate = useNavigate();
  const [email, setEmail] = useState('clinician@example.com');
  const [password, setPassword] = useState('demo-password');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await login(email, password);
      try {
        window.localStorage.removeItem('chatSessions:v1');
      } catch {
        // ignore storage errors
      }
      navigate('/app');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-slate-100/80 px-4 text-slate-900 dark:bg-slate-950 dark:text-slate-50">
      <div className="w-full max-w-md rounded-3xl border border-slate-200/60 bg-white/95 px-7 py-6 shadow-lg shadow-slate-900/5 backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/95">
        <div className="mb-6 flex items-start justify-between">
          <div>
            <h1 className="text-sm font-semibold tracking-tight">Drug Interaction Assistant</h1>
            <p className="mt-1 text-[11px] text-slate-500 dark:text-slate-400">
              Sign in to access the clinical decision support workspace.
            </p>
          </div>
          <button
            type="button"
            onClick={toggleTheme}
            className="rounded-full border border-slate-200/70 bg-slate-50 px-3 py-1 text-[11px] font-medium text-slate-700 shadow-sm hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
          >
            {theme === 'dark' ? 'Dark' : 'Light'} mode
          </button>
        </div>
        <form onSubmit={handleSubmit} className="space-y-3 text-xs">
          <div className="space-y-1.5">
            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-200">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 outline-none placeholder:text-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-50"
            />
          </div>
          <div className="space-y-1.5">
            <label className="block text-[11px] font-medium text-slate-700 dark:text-slate-200">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2 text-xs text-slate-900 outline-none placeholder:text-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-50"
            />
          </div>
          {error && (
            <div className="rounded-lg border border-red-500/30 bg-red-500/5 px-3 py-2 text-[11px] text-red-600 dark:border-red-500/40 dark:bg-red-500/10 dark:text-red-400">
              {error}
            </div>
          )}
          <button
            type="submit"
            disabled={loading}
            className="mt-2 w-full rounded-lg bg-emerald-500 px-3 py-2.5 text-xs font-semibold text-emerald-50 shadow-sm shadow-emerald-500/30 hover:bg-emerald-600 disabled:cursor-not-allowed disabled:bg-emerald-500/60"
          >
            {loading ? 'Signing in\b5' : 'Sign in to workspace'}
          </button>
          <p className="pt-3 text-[10px] leading-relaxed text-slate-500 dark:text-slate-400">
            This environment is for demonstration and prototyping of drug interaction decision support. Do not use with
            real patient identifiers.
          </p>
        </form>
      </div>
    </div>
  );
}
