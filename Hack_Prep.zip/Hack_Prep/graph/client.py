# graph/client.py
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import Chroma

import httpx

# Create HTTP client with verify=False for LangChain
client = httpx.Client(verify=False)

def get_azure_client():
    return ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure/genailab-maas-gpt-4o",
    api_key="sk-xA46m6ExMaLX4lRBXz5gfg",
    http_client=client,
    )


