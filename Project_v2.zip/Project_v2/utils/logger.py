# utils/logger.py
def log(msg):
    print(f"\n🔍 [DEBUG] {msg}\n")
