# main.py
import json
import traceback
from pathlib import Path
from graph.workflow import create_workflow
from graph.state import AgentState


def pretty_print(title, obj):
    print("\n" + "="*8 + f" {title} " + "="*8)
    try:
        print(json.dumps(obj, indent=2, ensure_ascii=False))
    except Exception:
        print(obj)
    print("="*32 + "\n")


def main():
    try:
        file_path = input("Enter PDF file path: ").strip().strip('"').strip("'")
        if not Path(file_path).exists():
            print("File not found:", file_path)
            return

        state = AgentState(file_path=file_path)
        app = create_workflow()

        result = app.invoke(state.model_dump())
        # Handle interrupts for human review
        while "__interrupt__" in result:
            interrupt_payload = result["__interrupt__"][0].value
            pretty_print("INVOICE JSON", interrupt_payload.get("invoice_data"))
            pretty_print("VALIDATION", interrupt_payload.get("validation"))
            print(interrupt_payload.get("question"))
            choice = input("Approve (a) | Reject (r): ").strip().lower()
            resume_decision = True if choice == "a" else False
            # Resume workflow with decision
            result = app.invoke({"resume": resume_decision})

        # Final result
        pretty_print("FINAL INVOICE JSON", result.get("invoice_data"))
        pretty_print("FINAL VALIDATION", result.get("validation"))
        if result.get("validation") and result["validation"].get("save_result"):
            print("Save result:", result["validation"]["save_result"])
        return
    except Exception as e:
        print("Unhandled error:", e)
        traceback.print_exc()
        input("Press Enter to exit...")


if __name__ == "__main__":
    main()
