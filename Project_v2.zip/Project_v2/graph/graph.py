# graph/graph.py
from langgraph.graph import StateGraph
from graph.state import AgentState
from graph.nodes import router_node, llm_node
from graph.tools import resolve_tool, interaction_tool, fda_tool, tavily_tool, single_drug_tool

def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("router", router_node)
    graph.add_node("resolve", resolve_tool)
    graph.add_node("interaction", interaction_tool)
    graph.add_node("fda", fda_tool)
    graph.add_node("tavily", tavily_tool)
    graph.add_node("single_drug_info", single_drug_tool)
    graph.add_node("llm", llm_node)

    graph.set_entry_point("router")

    def router_decision(state: AgentState):
        if not state.run_list:
            return "tavily"
        return state.run_list[0]

    graph.add_conditional_edges(
        "router",
        router_decision,
        {
            "resolve": "resolve",
            "interaction": "interaction",
            "fda": "fda",
            "tavily": "tavily",
            "single_drug_info": "single_drug_info",
        }
    )

    graph.add_edge("resolve", "llm")
    graph.add_edge("interaction", "llm")
    graph.add_edge("fda", "llm")
    graph.add_edge("tavily", "llm")
    graph.add_edge("single_drug_info", "llm")

    graph.set_finish_point("llm")
    return graph.compile()
