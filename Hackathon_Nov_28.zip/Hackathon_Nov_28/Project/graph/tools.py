# graph/tools.py
import requests
import os

API_BASE = "http://localhost:8000"
API_KEY = os.getenv("DEMO_API_KEY", "demo_key_1234")

def resolve_tool(state):
    drug1 = state.drugs[0]
    r = requests.get(f"{API_BASE}/resolve", params={"name": drug1})
    return {"resolved": r.json()}

def interaction_tool(state):
    d1, d2 = state.drugs[0], state.drugs[1]
    r = requests.get(
        f"{API_BASE}/interactions",
        params={"drug1": d1, "drug2": d2},
        headers={"x-api-key": API_KEY}
    )
    return {"interaction": r.json()}

def fda_tool(state):
    drug = state.drugs[0]
    r = requests.get(
        f"{API_BASE}/fda",
        params={"drug": drug},
        headers={"x-api-key": API_KEY}
    )
    return {"fda": r.json()}
