import { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';

interface ChatSessionSummary {
  id: string;
  title: string;
  createdAt: string;
}

export function Sidebar() {
  const navigate = useNavigate();
  const [recentSessions, setRecentSessions] = useState<ChatSessionSummary[]>([]);

  const loadSessions = () => {
    try {
      const raw = window.localStorage.getItem('chatSessions:v1');
      if (!raw) {
        setRecentSessions([]);
        return;
      }
      const parsed = JSON.parse(raw) as ChatSessionSummary[];
      if (!Array.isArray(parsed)) {
        setRecentSessions([]);
        return;
      }
      const sorted = [...parsed].sort((a, b) => (a.createdAt < b.createdAt ? 1 : -1));
      setRecentSessions(sorted.slice(0, 6));
    } catch {
      setRecentSessions([]);
    }
  };

  useEffect(() => {
    loadSessions();
    const handler = () => loadSessions();
    window.addEventListener('chatSessionsUpdated', handler);
    return () => window.removeEventListener('chatSessionsUpdated', handler);
  }, []);

  return (
    <aside className="flex w-60 flex-col border-r border-slate-200/20 bg-slate-950 text-slate-50">
      <div className="px-4 py-4 text-xs font-semibold uppercase tracking-widest text-slate-400">
        Navigation
      </div>
      <nav className="flex-1 space-y-1 px-2 text-sm">
        <button
          type="button"
          onClick={() => navigate('/app')}
          className="mb-2 w-full rounded-lg bg-emerald-500 px-3 py-2 text-left text-xs font-semibold text-emerald-50 shadow-sm hover:bg-emerald-600"
        >
          New Interaction Query
        </button>
        <div className="mt-3 rounded-lg bg-slate-900/60 px-3 py-3 text-[11px] text-slate-400">
          <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-500">Previous chats</div>
          {recentSessions.length === 0 ? (
            <p className="text-[10px] text-slate-500">No previous chats yet.</p>
          ) : (
            <div className="mt-1 space-y-1">
              {recentSessions.map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => navigate('/app')}
                  className="w-full truncate rounded-md bg-slate-800 px-2 py-1 text-left text-[11px] text-slate-100 hover:bg-slate-700"
                >
                  {s.title || 'Interaction'}
                </button>
              ))}
            </div>
          )}
        </div>
      </nav>
      <div className="border-t border-slate-800 px-4 py-3 text-[10px] text-slate-500">
        For clinical decision support only. Not a substitute for clinical judgment.
      </div>
    </aside>
  );
}
