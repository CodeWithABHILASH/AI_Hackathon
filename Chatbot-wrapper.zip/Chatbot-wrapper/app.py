import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from llm_client import call_llm
from py_memory import get_memory, add_message


class ChatRequest(BaseModel):
    userId: str
    message: str
    systemPrompt: str | None = "You are a helpful assistant."


load_dotenv()


app = FastAPI(title="Python Chatbot Wrapper")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/chat")
async def chat_endpoint(payload: ChatRequest):
    if not payload.userId or not payload.message:
        raise HTTPException(status_code=400, detail="userId and message required")

    memory = get_memory(payload.userId)

    messages = []
    if payload.systemPrompt:
        messages.append({"role": "system", "content": payload.systemPrompt})
    messages.extend(memory)
    messages.append({"role": "user", "content": payload.message})

    add_message(payload.userId, "user", payload.message)

    # For now, we send the last user message plus simple context text to the LLM.
    # You can replace this with a more advanced prompt that serializes full messages.
    combined_query = payload.message

    try:
        reply = call_llm(combined_query)
    except Exception as exc:  # noqa: BLE001
        import traceback

        traceback.print_exc()
        raise HTTPException(status_code=500, detail="Connection error.") from exc

    add_message(payload.userId, "assistant", reply)

    return {"reply": reply}


if __name__ == "__main__":
    import uvicorn

    port = int(os.environ.get("PORT", "8000"))
    uvicorn.run("app:app", host="0.0.0.0", port=port, reload=True)
