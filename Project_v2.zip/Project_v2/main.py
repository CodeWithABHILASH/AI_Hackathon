# main.py
from graph.graph import build_graph
from graph.state import AgentState

graph = build_graph()

def run_turn(user_query: str):
    state = AgentState(query=user_query)
    output = graph.invoke(state.model_dump())
    print("[DEBUG] Raw graph output:", output)

    # Try to extract summary from output
    if isinstance(output, dict):
        if "llm" in output:
            llm_out = output["llm"]
            if isinstance(llm_out, dict) and "summary" in llm_out:
                return llm_out["summary"]
            elif isinstance(llm_out, str):
                return llm_out
        if "summary" in output:
            return output["summary"]
    return "Something went wrong."

if __name__ == "__main__":
    print("TATA Medical Assistant (type quit to exit)\n")

    while True:
        msg = input("You: ")
        if msg.lower() in ["quit", "exit"]:
            print("Bot: Take care!")
            break

        print("Bot:", run_turn(msg))
