import sys
import os


from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser

# Local Imports
from llm_client import get_llm
from graph.state import GraphState
from graph.router import route_query
from graph.utils import create_vectordb

def decision_node(state: GraphState) -> GraphState:
    print(f"\n🤔 processing query: {state.query}")
    res = route_query(state.query)
    print(f"👉 Router Decision: {res}")
    
    classification = res.get('classifier', '').lower()
    
    if "compare" in classification:
        flow_type = "comparison"
    elif "end" in classification:
        flow_type = "end"
    else:
        flow_type = "rag"
    
    # Use standard copy for simplicity and compatibility
    return state.copy(update={"flow_type": flow_type})

def comparison_node(state: GraphState) -> GraphState:
    print("⚖️ Executing Comparison...")
    doc1, doc2 = state.document_texts
    
    # Simple set comparison logic
    common_text = list(set(doc1.split()) & set(doc2.split()))[:10]
    differences = list(set(doc1.split()) ^ set(doc2.split()))[:10]
    
    results = {
        "common": common_text,
        "differences": differences
    }
    return state.copy(update={"comparison_results": results})

def qa_node(state: GraphState) -> GraphState:
    print("🧠 Executing QA (Modern LCEL RAG)...")
    
    # 1. Setup VectorDB & Retriever
    vectordb = create_vectordb(state.document_texts)
    retriever = vectordb.as_retriever()
    llm = get_llm()

    # 2. Define the Prompt
    template = """Answer the question based only on the following context:
    {context}

    Question: {question}
    """
    prompt = ChatPromptTemplate.from_template(template)

    # 3. Helper to format docs
    def format_docs(docs):
        return "\n\n".join(doc.page_content for doc in docs)

    # 4. Build the Modern LCEL Chain
    # (No hidden memory or legacy chains here)
    rag_chain = (
        {"context": retriever | format_docs, "question": RunnablePassthrough()}
        | prompt
        | llm
        | StrOutputParser()
    )

    # 5. Invoke
    answer = rag_chain.invoke(state.query)
    
    return state.copy(update={"rag_answer": answer})

def end_node(state: GraphState) -> GraphState:
    print("👋 Workflow Ending.")
    return state