import requests
import os
from llm_client import get_embeddings 
from langchain_community.vectorstores import Chroma

# === Monkeypatch requests to disable SSL verification globally ===
for method in ("get", "post", "put", "delete", "head", "options", "patch"):
    original = getattr(requests, method)

    def insecure_request(*args, _original=original, **kwargs):
        kwargs["verify"] = False
        return _original(*args, **kwargs)

    setattr(requests, method, insecure_request)

def create_vectordb(docs):
    embeddings = get_embeddings()
    vector_store = Chroma.from_documents(documents=docs, embedding=embeddings, persist_directory="./chroma_index")
    vector_store.persist()
    return vector_store

def get_vector_store_retriever():
    embeddings = get_embeddings()
    try:
        # db = FAISS.load_local('faiss_index', embeddings, allow_dangerous_deserialization=True)
        # Initialize the embedding model
        embedding_model = get_embeddings()

        # Load the persisted vector store
        db = Chroma(persist_directory="./chroma_index", embedding_function=embedding_model)
        return db.as_retriever(search_type="similarity", search_kwargs={"k": 20}, verbose=True)
    except Exception:
        return None