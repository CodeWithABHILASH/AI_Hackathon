from typing import Dict, List, Optional
from pydantic import BaseModel, Field

class GraphState(BaseModel):
    query: str = Field(default="", description="User query input")
    flow_type: Optional[str] = Field(default=None, description="Path decision: 'comparison', 'rag', or 'end'")
    document_texts: List[str] = Field(default=None, description="Source documents")
    comparison_results: Optional[Dict[str, List[str]]] = Field(default=None, description="Results from comparison")
    rag_answer: Optional[str] = Field(default=None, description="Answer from QA")