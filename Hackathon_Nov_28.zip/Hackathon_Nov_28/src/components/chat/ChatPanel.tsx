import { FormEvent, useEffect, useState } from 'react';

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  createdAt: string;
}

interface InteractionDetails {
  drug1?: string;
  drug2?: string;
  severity?: string;
  description?: string;
  mechanism?: string;
  fdaCount?: number;
  sources?: string[];
}

interface ChatSession {
  id: string;
  title: string;
  createdAt: string;
  messages: ChatMessage[];
  lastDetails?: InteractionDetails | null;
}

export function ChatPanel() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [details, setDetails] = useState<InteractionDetails | null>(null);
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState<string | null>(null);

  // Load sessions from localStorage on first mount
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem('chatSessions:v1');
      if (raw) {
        const parsed = JSON.parse(raw) as ChatSession[];
        if (Array.isArray(parsed) && parsed.length > 0) {
          setSessions(parsed);
          setActiveSessionId(parsed[0].id);
          setMessages(parsed[0].messages);
          setDetails(parsed[0].lastDetails ?? null);
          return;
        }
      }
    } catch {
      // ignore parse errors and fall back to empty
    }

    const initialId = crypto.randomUUID();
    const initial: ChatSession = {
      id: initialId,
      title: 'New interaction',
      createdAt: new Date().toISOString(),
      messages: [],
      lastDetails: null,
    };
    setSessions([initial]);
    setActiveSessionId(initialId);
  }, []);

  // Persist current session whenever messages or details change
  useEffect(() => {
    if (!activeSessionId) return;
    setSessions((prev) => {
      if (prev.length === 0) return prev;
      const idx = prev.findIndex((s) => s.id === activeSessionId);
      const titleSource = messages.find((m) => m.role === 'user');
      const nextTitle = titleSource?.content.slice(0, 60) || 'New interaction';
      const updatedSession: ChatSession = {
        id: activeSessionId,
        title: nextTitle,
        createdAt: prev[idx]?.createdAt || new Date().toISOString(),
        messages,
        lastDetails: details,
      };

      let nextSessions: ChatSession[];
      if (idx === -1) {
        nextSessions = [updatedSession, ...prev];
      } else {
        nextSessions = prev.slice();
        nextSessions[idx] = updatedSession;
      }

      try {
        window.localStorage.setItem('chatSessions:v1', JSON.stringify(nextSessions));
        try {
          window.dispatchEvent(new Event('chatSessionsUpdated'));
        } catch {
          // ignore event dispatch errors
        }
      } catch {
        // ignore storage errors
      }

      return nextSessions;
    });
  }, [activeSessionId, messages, details]);

  const handleSelectSession = (id: string) => {
    setActiveSessionId(id);
    const session = sessions.find((s) => s.id === id);
    if (session) {
      setMessages(session.messages);
      setDetails(session.lastDetails ?? null);
    }
  };

  const handleNewChat = () => {
    const id = crypto.randomUUID();
    const session: ChatSession = {
      id,
      title: 'New interaction',
      createdAt: new Date().toISOString(),
      messages: [],
      lastDetails: null,
    };
    setSessions((prev) => [session, ...prev]);
    setActiveSessionId(id);
    setMessages([]);
    setDetails(null);
    setInput('');
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      role: 'user',
      content: input.trim(),
      createdAt: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch('http://localhost:8000/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': 'demo_key_1234',
        },
        body: JSON.stringify({ query: userMessage.content }),
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(errorText || `Request failed with status ${response.status}`);
      }

      const data = (await response.json()) as { summary?: string; raw?: any };

      if (data.raw && typeof data.raw === 'object') {
        try {
          const raw = data.raw as any;
          const interactionData = raw.interaction;
          const fdaData = raw.fda;

          const next: InteractionDetails = {};

          if (interactionData && typeof interactionData === 'object') {
            const base = interactionData as any;
            const inner = base.interaction ?? base;

            next.drug1 = base.drug1 ?? next.drug1;
            next.drug2 = base.drug2 ?? next.drug2;
            next.severity = inner?.severity ?? next.severity;
            next.description = inner?.description ?? next.description;
            next.mechanism = inner?.mechanism ?? next.mechanism;
            if (Array.isArray(base.found_in)) {
              next.sources = base.found_in;
            }
          }

          if (fdaData && typeof fdaData === 'object') {
            const fd = fdaData as any;
            const results = fd.raw?.results;
            if (Array.isArray(results)) {
              next.fdaCount = results.length;
            }
          }

          // Only set details if we actually extracted something useful
          if (
            next.drug1 ||
            next.drug2 ||
            next.severity ||
            next.description ||
            next.mechanism ||
            typeof next.fdaCount === 'number' ||
            (next.sources && next.sources.length > 0)
          ) {
            setDetails(next);
          } else {
            setDetails(null);
          }
        } catch {
          setDetails(null);
        }
      } else {
        setDetails(null);
      }

      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content:
          data.summary ||
          'The backend did not return a summary. Please check the query format or backend configuration.',
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (err) {
      setDetails(null);
      const assistantMessage: ChatMessage = {
        id: crypto.randomUUID(),
        role: 'assistant',
        content:
          err instanceof Error
            ? `There was an error contacting the interaction backend: ${err.message}`
            : 'There was an unexpected error contacting the interaction backend.',
        createdAt: new Date().toISOString(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex h-full flex-col rounded-2xl border border-slate-200/60 bg-slate-50/90 pb-4 pt-2 shadow-sm dark:border-slate-800 dark:bg-slate-950/70">
      <div className="flex items-center justify-between border-b border-slate-200/60 px-5 pb-3 pt-2 text-xs font-semibold text-slate-800 dark:border-slate-800 dark:text-slate-100">
        <div className="flex flex-col">
          <span className="text-[11px] uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Conversational agent</span>
          {sessions.length > 1 && activeSessionId && (
            <div className="mt-1 flex flex-wrap items-center gap-2 text-[11px] font-normal text-slate-500 dark:text-slate-400">
              <span className="text-[10px] uppercase tracking-[0.18em] text-slate-400">Previous chats</span>
              <div className="flex flex-wrap gap-1">
                {sessions.map((s) => (
                  <button
                    key={s.id}
                    type="button"
                    onClick={() => handleSelectSession(s.id)}
                    className={`rounded-full px-2 py-0.5 text-[10px] ${
                      s.id === activeSessionId
                        ? 'bg-emerald-500/20 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-200'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200'
                    }`}
                  >
                    {s.title || 'Interaction'}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleNewChat}
            className="rounded-full border border-slate-200/60 bg-white px-3 py-1 text-[11px] font-medium text-slate-700 shadow-sm hover:bg-slate-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            New chat
          </button>
        </div>
      </div>

      <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4 text-[13px] leading-relaxed">
        {messages.length === 0 && (
          <div className="max-w-xl rounded-xl border border-dashed border-slate-300/70 bg-slate-100/80 p-5 text-[12px] text-slate-500 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-400">
            Ask about potential interactions between one or more drugs.
            <br />
            <span className="mt-1 block text-[11px] text-slate-500/90 dark:text-slate-400/90">
              Example: "Are there clinically significant interactions between warfarin and amoxicillin?"
            </span>
          </div>
        )}
        {messages.map((m) => {
          const content =
            m.role === 'assistant' ? m.content.replace(/[\*#]/g, '') : m.content;

          return (
            <div
              key={m.id}
              className={`max-w-[75%] rounded-2xl px-3.5 py-2.5 text-[12px] leading-relaxed shadow-sm ${
                m.role === 'user'
                  ? 'ml-auto bg-blue-600 text-blue-50'
                  : 'mr-auto bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-50'
              }`}
            >
              <div className="mb-1 text-[10px] font-semibold uppercase tracking-[0.18em] opacity-70">
                {m.role === 'user' ? 'You' : 'Assistant'}
              </div>
              <div className={m.role === 'assistant' ? 'whitespace-pre-line' : ''}>{content}</div>
            </div>
          );
        })}
        {loading && (
          <div className="mr-auto flex max-w-[65%] items-center gap-2 rounded-2xl bg-slate-100 px-3.5 py-2.5 text-[11px] text-slate-500 dark:bg-slate-800 dark:text-slate-300">
            <span className="h-2 w-2 animate-pulse rounded-full bg-emerald-500" />
            <span>Consulting drug interaction knowledge base5</span>
          </div>
        )}
        {details && (
          <div className="mt-2 max-w-xl rounded-2xl border border-slate-200/70 bg-white/80 px-4 py-3 text-[12px] shadow-sm dark:border-slate-800 dark:bg-slate-900/80">
            <div className="mb-1 flex items-center justify-between text-[11px] font-semibold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">
              <span>Interaction details</span>
              {details.severity && (
                <span className="rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-medium text-emerald-600 dark:text-emerald-400">
                  Severity: {details.severity}
                </span>
              )}
            </div>
            {(details.drug1 || details.drug2) && (
              <p className="text-[12px] text-slate-700 dark:text-slate-200">
                Drugs:&nbsp;
                <span className="font-medium">
                  {[details.drug1, details.drug2].filter(Boolean).join(' and ')}
                </span>
              </p>
            )}
            {details.description && (
              <p className="mt-1 text-[12px] text-slate-700 dark:text-slate-200">
                {details.description}
              </p>
            )}
            {details.mechanism && (
              <p className="mt-1 text-[12px] text-slate-700 dark:text-slate-200">
                <span className="font-medium">Mechanism: </span>
                {details.mechanism}
              </p>
            )}
            {(typeof details.fdaCount === 'number' || (details.sources && details.sources.length > 0)) && (
              <div className="mt-2 flex flex-wrap gap-2 text-[11px] text-slate-500 dark:text-slate-400">
                {typeof details.fdaCount === 'number' && (
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 dark:bg-slate-800">
                    FDA cases: {details.fdaCount}
                  </span>
                )}
                {details.sources && details.sources.length > 0 && (
                  <span className="rounded-full bg-slate-100 px-2 py-0.5 dark:bg-slate-800">
                    Sources: {details.sources.join(', ')}
                  </span>
                )}
              </div>
            )}
          </div>
        )}
      </div>
      <form onSubmit={handleSubmit} className="border-t border-slate-200/60 px-5 pb-3 pt-2 dark:border-slate-800">
        <div className="flex gap-3">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={3}
            className="flex-1 resize-none rounded-xl border border-slate-200 bg-white px-3.5 py-2.5 text-[12px] text-slate-900 shadow-sm outline-none placeholder:text-slate-400 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-50"
            placeholder="Describe the drugs and any relevant context (dose, route, patient factors). Keep it concise but clinically specific."
          />
          <button
            type="submit"
            disabled={loading}
            className="self-end rounded-lg bg-emerald-500 px-4 py-2.5 text-[12px] font-semibold text-emerald-50 shadow-sm hover:bg-emerald-600 disabled:cursor-not-allowed disabled:bg-emerald-500/60"
          >
            {loading ? 'Analyzing' : 'Ask'}
          </button>
        </div>
      </form>
    </div>
  );
}